package com.eosgrp.jdbc.config;

public class DbConfig {

    public static final String URL =
        "jdbc:sqlserver://127.0.0.1:13001;databaseName=Northwinds2024Student;encrypt=false;trustServerCertificate=true";

    public static final String USER = "sa";
    public static final String PASSWORD = "YourStrong!Pass123";
}