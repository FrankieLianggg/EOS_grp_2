# JDBC Class Library Project - EOS_grp_2

## Overview
This is a starter submission package for a Java JDBC class library project using the Microsoft JDBC Driver for SQL Server.

## Project Structure
- `src/main/java/com/eosgrp/jdbc/...` main source code
- `src/test/java/com/eosgrp/jdbc/ConnectionTest.java` connection test
- `docs/` project documentation
- `pom.xml` Maven build file

## Before You Run
Update `src/main/java/com/eosgrp/jdbc/config/DbConfig.java` with your real:
- server name
- database name
- username
- password

## Run with Maven
Compile:
```bash
mvn compile
```

Run connection test:
```bash
mvn exec:java -Dexec.mainClass="com.eosgrp.jdbc.ConnectionTest" -Dexec.classpathScope=test
```

Run UI:
```bash
mvn exec:java -Dexec.mainClass="com.eosgrp.jdbc.ui.MainUI"
```

## Notes
- This is a starter package. You may need to adjust SQL table and column names to match your local database.
- For Northwinds2024Student, verify whether your schema uses `Sales.Customer`, `Sales.[Order]`, and `Production.Product` exactly.
