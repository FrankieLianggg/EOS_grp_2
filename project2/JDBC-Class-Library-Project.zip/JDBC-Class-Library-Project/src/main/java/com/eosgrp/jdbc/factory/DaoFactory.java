package com.eosgrp.jdbc.factory;

import com.eosgrp.jdbc.dao.CustomerDao;
import com.eosgrp.jdbc.dao.OrderDao;
import com.eosgrp.jdbc.dao.ProductDao;

public class DaoFactory {

    private DaoFactory() {
    }

    public static CustomerDao getCustomerDao() {
        return new CustomerDao();
    }

    public static OrderDao getOrderDao() {
        return new OrderDao();
    }

    public static ProductDao getProductDao() {
        return new ProductDao();
    }
}
